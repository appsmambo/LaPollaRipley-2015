<?php

class HomeController extends BaseController {

	public function postRegistro()
	{
		$messages = array(
			'required'		=> 'El campo :attribute es obligatorio.',
			'email'			=> 'Ingrese su cuenta de email.',
			'string'		=> 'El campo solo permite letras.',
			'digits'		=> 'El campo solo permite números.',
			'dni.unique'	=> 'El dni ingresado ya está registrado en nuestro sistema.',
			'email.unique'	=> 'El email ingresado ya está registrado en nuestro sistema.'
		);
		$rules = array(
			'tipo_compra'	=> 'required',
			'nro_ticket'	=> 'required',
			'nro_tarjeta'	=> 'required',
			'nombres'		=> 'required|string',
			'apellidos'		=> 'required|string',
			'direccion'		=> 'required',
			'telefono'		=> 'required',
			'dni'			=> 'required|digits:8|unique:participante',
			'email'			=> 'required|email|unique:participante',
			'campeon'		=> 'required',
			'subcampeon'	=> 'required',
			'tercero'		=> 'required',
			'cuarto'		=> 'required',
		);

		$validator = Validator::make(Input::all(), $rules, $messages);

		if ($validator->fails()) {
			$messages = $validator->messages();
			$respuesta = array('success' => 'error', 'messages' => $messages);
			return Response::json($respuesta, 200);
		} else {
			$participante = new Participante();
			$participante->tipo_compra	= Input::get('tipo_compra');
			$participante->nro_ticket	= Input::get('nro_ticket');
			$participante->nro_tarjeta	= Input::get('nro_tarjeta');
			$participante->nombres		= ucwords(strtolower(trim(Input::get('nombres'))));
			$participante->apellidos	= ucwords(strtolower(trim(Input::get('apellidos'))));
			$participante->direccion	= trim(Input::get('direccion'));
			$participante->telefono		= Input::get('telefono');
			$participante->dni			= Input::get('dni');
			$participante->email		= strtolower(Input::get('email'));
			$participante->campeon		= Input::get('campeon');
			$participante->subcampeon	= Input::get('subcampeon');
			$participante->tercero		= Input::get('tercero');
			$participante->cuarto		= Input::get('cuarto');
			$participante->ip			= Request::getClientIp(true);
			$participante->save();

			$respuesta = array('success' => 'ok');
			return Response::json($respuesta, 200);

		}
	}

}
